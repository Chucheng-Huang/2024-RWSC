
function [Objs,ACCs,NMIs,retCent,retInd] = AVEkmeans1(X,gnd, c, num)
    [n,d] = size(X);     
    ACCs = zeros(num,1);
    NMIs = zeros(num,1);
    Objs = zeros(num,1);
    
    minObj = 10^10;
    for j = 1:num
        Y = zeros(n,c);
        [ind, cent]= kmeans(X,c);
        for i =1:n
            Y(i,ind(i)) = 1;
        end
        Objs(j) = norm( X - Y*cent, 'fro' ); %
        if Objs(j) < minObj
            minObj = Objs(j);
            retCent = cent;
            retInd = ind;
        end
        ACCs(j) = ACC2(gnd,ind,c);
        NMIs(j) = NMI(gnd,ind);
    end
end
