clc; clear

%% Data
load 'iris\data.txt';
load 'iris\gnd.txt'; 
X = data;

%% Parameter
c = length(unique(gnd));
NeighborK   = 15;

[n,d] = size(X); 
if d < 20
    rL  = [2:1:d];   %dimentionality
elseif d < 100
    rL = [5:5:d];
else
  % 当维度大于100时，用PCA预处理加速
    [eigvector, eigvalue, elapse] = PCA_dencai(X, 100); 
    projection=eigvector;
    X = X* projection;
    [n,d] = size(X); 
    rL = [10:10:d];
end

muL    = [10^-3,10^-2,10^-1,10^0,10^1,10^2,10^3];
etaL   = [10^-3,10^-2,10^-1,10^0,10^1,10^2,10^3];
gammaL = [10^-3,10^-2,10^-1,10^0,10^1,10^2,10^3];
NITER  = 30;

%% RWSC
optAcc  = 0;
step    = 0;
tag = 1;
Record  = [];
for ri =1:1:length(rL)
    r  = rL(ri);
    for i=1:1:length(muL)
        mu = muL(i);
        for j=1:1:length(etaL)
            eta = etaL(j);
            for k = 1:1:length(gammaL) 
                gamma = gammaL(k);
                step = step + 1;
                tic;
                [S,P,W,loss] = RWSC(X,NeighborK,r,mu,eta,gamma,NITER);
                times = toc;

                [ind, cent]= kmeans(X*P*W, c, "Replicates",20);
                tempACC = ACC2(gnd,ind,c);
                tempNMI = NMI(gnd,ind);
 
                tmp = [step,r,mu,eta,gamma,times,tempNMI,tempACC];
                Record = [Record;tmp];
                if tempACC > optAcc
                    Paras{tag} = {S,tmp,P,W,loss};
                    optAcc = tempACC; 
                end
                fprintf('Step (Ours_LPP_PCA): id=%d,r =%d, mu= %f,eta= %f,gamma= %f,times = %f s, Nmi = %f,acc = %f\n',step,r,mu,eta,gamma,times,tempNMI,tempACC);
            end
        end
    end
end
Records{tag} = Record;
tmp = Paras{tag}{2};
fprintf('opt_Step (Ours_LPP_PCA): id=%d,r =%d, mu = %f,eta = %f,gamma= %f,times = %f s,Nmi = %f, acc = %f \n \n',tmp(1),tmp(2),tmp(3),tmp(4),tmp(5),tmp(6),tmp(7),tmp(8));


