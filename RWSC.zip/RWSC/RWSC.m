function [S,P,W,loss] = RWSC(X,k,r,mu,eta,gamma,NITER)
%   Objective Funtion:
%   min_{S,P,W}  sum_ij ||xiPW - xjPW ||_2^2sij - mu*tr(W'*P'*Gt*P*W) + eta*tr(W'W) + gamma*||S||_F^2
%   s.t. S>=0, sii = 0,si*1^T = 1, P^TP=I_r,W = diag(w), w*1^T = 1,w>=0.

    [n,d] = size(X);

    % Init W
    w = 1/r*ones(1,r);
    W = diag(w);
     
    % Init P
    H = eye(n)-1/n*ones(n);
    Gt = X'*H*X  + 10^-6*eye(d);
    [P,~] = eigs(Gt, r);
    
    loss = [];    
    for iter = 1:NITER

        % Update S
        dist = L2_distance_1(W'*P'*X', W'*P'*X');   
        [~, idx] = sort(dist,2);
        S = zeros(n);
        for i=1:n
            idxa0 = idx(i,2:k+1);
            dxi = dist(i,idxa0);
            ad      = -dxi/(2*gamma);
            S(i,idxa0) = EProjSimplex_new(ad);
        end


        % Update P     
        Ls = diag(sum(S)) - S - S' + diag(sum(S')); 
        M = X'*Ls*X;
        A = M - mu*Gt;
        P = GPI2(P, W, A, 100);

        % Udpate W
        PM = (P'*M*P).*eye(r);
        PG = (P'*Gt*P).*eye(r);
        PP = zeros(1,r);
        [w, obj]=mSimplexRepresentation(PM - mu*PG + eta*eye(r),PP,w); %    min x*H*x' + f*x'   subject to:  x>=0, x*1'=1
        W = diag(w);
        
        loss(iter) = trace(W'*P'*M*P*W) - mu*trace(W'*P'*Gt*P*W)  + eta * trace(W*W')+  gamma*(norm(S, 'fro'))^2;
       
        if iter>10 && abs(loss(iter) - loss(iter - 1))  < 10^-6
            return 
        end   
    end
end


