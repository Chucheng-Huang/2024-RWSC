% min Tr(P'APWW')
% s.t. P'P=I_k
% P   m*k
% A   m*m
% W   k*k

function [P,obj]=GPI2(P, W, A, Niter)
    [m,k] = size(P);

    [~,sigma,~] = svd(A + 10^3*eye(m));
    alpha =  max( abs( diag(sigma) )) + 10^3;
    I = eye(m);
    
    P =ones(m,k);
    [u,~,v]= svd(P);
    P = u(:,1:k)*v';
   
    AA = alpha*I - A;
    obj =[];
    for i =1: Niter
        M = 2*AA*P*W*W';
        [U,sigma,V] = svd(M);
        P = U(:,1:k)*V';
        obj(i) = trace(W'*P'*A*P*W);

        if i >= 2 
            if   abs(obj(i) - obj(i-1)) < 1e-10 
                break;
            end
        end 
    end
end
