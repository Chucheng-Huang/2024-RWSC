
%   min x*H*x' + f*x'   subject to:  x>=0, x*1'=1
function [x, obj]=mSimplexRepresentation(H,f,x0)


NIter = 150;
NStop = 20;

n = size(H,1);

if nargin < 3
    x = 1/n*ones(1,n);
else
    x = x0;
end

x1 = x;
t = 1;
t1 = 0;
[~,v,] = svd(H );
L = 2* max(diag(v)); 
r = 1/(L + eps);

obj =[];
for iter = 1:NIter
    p = (t1-1)/t;
    s = x + p*(x-x1);
    x1 = x;
    g = s * (H + H') + f;  
    ob1 = x*H*x' + f*x' ;  
    for it = 1:NStop
        z = s - r*g;
        z = EProjSimplex_new(z);
        ob =z*H*z' + f*z' ;
        if ob1 < ob
            r = 0.5*r;
        else
            break;
        end
    end
    if it == NStop
        obj = [obj; ob];
        %disp('not');
        break;
    end
    x = z;
    t1 = t;
    t = (1+sqrt(1+4*t^2))/2;
    
    obj = [obj; ob];
%     obj(iter) = ob;
end
